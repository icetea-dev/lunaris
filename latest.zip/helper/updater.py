import aiohttp
import asyncio
import zipfile
import os
import json

class Updater:
    default_settings = {
        "settings": {
            "token": "",
            "prefix": ",",
            "ping_replier": {
                "enabled": False,
                "message": ""
            },
            "rpc": {
                "enabled": False,
                "client_id": "",
                "large_image": "",
                "details": "",
                "state": "",
                "button1": {
                    "enabled": True,
                    "label": "",
                    "url": ""
                },
                "button2": {
                    "enabled": True,
                    "label": "",
                    "url": ""
                }
            },
            "log": {
                "log_ping_webhook": ""
            }
        }
    }

    appdata_path = os.getenv('APPDATA')
    lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
    settings_file = os.path.join(lunaris_folder, 'settings.json')

    def __init__(self, local_version_file):
        self.local_version_file = local_version_file
        self.remote_version_url = 'https://raw.githubusercontent.com/icetea-dev/lunaris/main/remote_version.txt'
        self.update_url = 'https://github.com/icetea-dev/lunaris/main/latest.zip'
        self.current_directory = os.path.dirname(os.path.abspath(__file__))

    async def get_remote_version(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(self.remote_version_url) as response:
                if response.status == 200:
                    return await response.text()
                else:
                    raise Exception(f"Failed to fetch remote version: {response.status}")

    def get_local_version(self):
        try:
            with open(self.local_version_file, 'r') as file:
                return file.read().strip()
        except FileNotFoundError:
            return None

    def update_local_version(self, new_version):
        with open(self.local_version_file, 'w') as file:
            file.write(new_version)

    async def download_update(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(self.update_url) as response:
                if response.status == 200:
                    update_path = os.path.join(self.current_directory, 'update.zip')
                    with open(update_path, 'wb') as file:
                        file.write(await response.read())
                    print("Update downloaded.")
                    self.apply_update(update_path)
                else:
                    raise Exception(f"Failed to download update: {response.status}")

    def apply_update(self, update_path):
        with zipfile.ZipFile(update_path, 'r') as zip_ref:
            zip_ref.extractall(self.current_directory)
        os.remove(update_path)
        print("Update applied.")

    @classmethod
    def load_and_update_settings(cls):
        if not os.path.exists(cls.lunaris_folder):
            os.makedirs(cls.lunaris_folder)

        if not os.path.exists(cls.settings_file):
            with open(cls.settings_file, 'w') as f:
                json.dump(cls.default_settings, f, indent=4)

        with open(cls.settings_file, 'r') as f:
            settings = json.load(f)

        def update_dict(original, updates):
            for key, value in updates.items():
                if isinstance(value, dict):
                    original[key] = update_dict(original.get(key, {}), value)
                else:
                    original.setdefault(key, value)
            return original

        updated_settings = update_dict(settings, cls.default_settings)

        with open(cls.settings_file, 'w') as f:
            json.dump(updated_settings, f, indent=4)

        return updated_settings

    async def check_for_update(self):
        local_version = self.get_local_version()
        remote_version = await self.get_remote_version()

        if local_version != remote_version:
            print(f"Updating from version {local_version} to {remote_version}")
            await self.download_update()
            self.update_local_version(remote_version)
        else:
            print("Already up-to-date.")
