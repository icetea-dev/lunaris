import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        


class DraggableMainWindow(Ui_MainWindow, QtWidgets.QMainWindow):
    
    def __init__(self = None):
        super().__init__()
        self.setupUi(self)
        self.dragging = False
        self.old_pos = None

    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = True
            self.old_pos = event.globalPos()

    
    def mouseMoveEvent(self, event):
        if self.dragging:
            delta = event.globalPos() - self.old_pos
            self.move(self.pos() + delta)
            self.old_pos = event.globalPos()

    
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = False

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = DraggableMainWindow()
    window.show()
    sys.exit(app.exec_())
