from colorama import Fore, init
from json import loads
from threading import RLock
from datetime import datetime
import os

class Console:
    __qualname__ = 'Console'

    def __init__(self):
        init()
        self.lock = RLock()
        self.banner = " \n                                                                     __   \n                                                         __ _  ___  / /_  \n                                                        / _` |/ _ \\| '_ \\ \n                                                       | (_| | (_) | (_) |\n                                                        \\__, |\\___/ \\___/ \n                                           |___/\n "
        self.width = os.get_terminal_size().columns
        self.main_color = Fore.LIGHTMAGENTA_EX
    
    def getTime(self):
        return datetime.now().strftime('%H:%M:%S')
    
    def padRight(self, l):
        return l
    
    def clear(self):
        os.system('cls')

    def title(self, title):
        os.system(f'''title {title}''')

    def center(self, text, options = (False,)):
        nn = []
        if options:
            spl = self.padRight(text.splitlines())
        spl = text.splitlines()
        i = 0
        for line in spl:
            line = line.strip('\n')
            if line.count(' ') != len(line):
                if options:
                    dn = self.width // 2 - len(line) // 3
                dn = self.width // 2 - len(line) // 2
                if i + 1 == len(spl):
                    nn.append(f'''{dn * ' '}{line}''')
                nn.append(f'''{dn * ' '}{line}\n''')
            i += 1
            return ''.join(nn)
        
    def logo(self):
        print(f'''{self.main_color}{self.center(self.banner)}''')

    def check(self, text, color):
        spl = text.split('->')
        if len(spl) > 1:
            pass
        return text
    
    def info(self, text):
        self.lock.acquire()
        current_time = self.getTime()
        print(f'''[{current_time}] {Fore.LIGHTCYAN_EX}[INFO] {self.check(text, Fore.LIGHTWHITE_EX)}{Fore.RESET}''')
        self.lock.release()

    def success(self, text):
        self.lock.acquire()
        current_time = self.getTime()
        print(f'''[{current_time}] {Fore.LIGHTGREEN_EX}[SUCCESS] {self.check(text, Fore.LIGHTGREEN_EX)}{Fore.RESET}''')
        self.lock.release()

    def error(self, text):
        self.lock.acquire()
        current_time = self.getTime()
        print(f'''[{current_time}] {Fore.LIGHTRED_EX}[ERROR] {self.check(text, Fore.LIGHTRED_EX)}{Fore.RESET}''')
        self.lock.release()

    def input(self, text):
        current_time = self.getTime()
        print(f'''[{current_time}] {Fore.LIGHTWHITE_EX}[INPUT] {self.check(text, Fore.LIGHTWHITE_EX)}{Fore.RESET}''')
