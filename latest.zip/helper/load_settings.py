import json, os

appdata_path = os.getenv('APPDATA')
lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
settings_file = os.path.join(lunaris_folder, 'settings.json')

def load_settings():
    with open(settings_file, 'r', encoding='utf-8') as f:
        return json.load(f)
