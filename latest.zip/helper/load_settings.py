import json, os
from helper.updater import Updater

appdata_path = os.getenv('APPDATA')
lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
settings_file = os.path.join(lunaris_folder, 'settings.json')

def load_settings():
    if not os.path.exists(lunaris_folder):
        os.makedirs(lunaris_folder)
    if not os.path.exists(settings_file):
        Updater.load_and_update_settings()
    with open(settings_file, 'r', encoding='utf-8') as f:
        return json.load(f)
