from discord.ext import commands
import asyncio
import json, os, sys, random, string, aiohttp, io, requests, subprocess, base64, re, time, contextlib
import urllib.parse
import urllib.request
from discord.ext import tasks
import discord

appdata_path = os.getenv('APPDATA')
lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
settings_file = os.path.join(lunaris_folder, 'settings', 'settings.json')

def load_settings():
    with open(settings_file, 'r', encoding='utf-8') as f:
        return json.load(f)

settings = load_settings()["settings"]
ping_replier = settings["ping_replier"]
rpc_settings = settings["rpc"]

def save_settings(new_settings):
    with open(settings_file, 'w', encoding='utf-8') as f:
        json.dump(new_settings, f, indent=4)

async def delete_response_after_delay(response, delay):
    await asyncio.sleep(delay)
    try:
        await response.delete()
    except discord.NotFound:
        pass
    except discord.Forbidden:
        pass
    except Exception as e:
        pass

def get_random_user_agent():
        userAgents = ["Mozilla/5.0 (Windows NT 6.2;en-US) AppleWebKit/537.32.36 (KHTML, live Gecko) Chrome/56.0.3075.83 Safari/537.32", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.1", "Mozilla/5.0 (Windows NT 8.0; WOW64) AppleWebKit/536.24 (KHTML, like Gecko) Chrome/32.0.2019.89 Safari/536.24", "Mozilla/5.0 (Windows NT 5.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.41 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3058.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3258.0 Safari/537.36", "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36", "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2599.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.35 (KHTML, like Gecko) Chrome/27.0.1453.0 Safari/537.35", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.139 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/6.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.0.9757 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.1", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3258.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/6.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.1", "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2151.2 Safari/537.36", "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1204.0 Safari/537.1", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/67.0.3387.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.0.9757 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3359.181 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.81 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3251.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/538 (KHTML, like Gecko) Chrome/36 Safari/538", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.18 Safari/535.1", "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.3 (KHTML, like Gecko) Chrome/5.0.355.0 Safari/533.3", "Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.4 Safari/532.0", "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.35 (KHTML, like Gecko) Chrome/27.0.1453.0 Safari/537.35", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3359.181 Safari/537.36", "Mozilla/5.0 (Windows NT 10.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36", "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3057.0 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.14 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.14", "Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36 TC2", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3058.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3258.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2531.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.81 Safari/537.36", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36,gzip(gfe)", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2264.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.150 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.45 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.14 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.14", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2714.0 Safari/537.36", "24.0.1284.0.0 (Windows NT 5.1) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/24.0.1284.0.3.742.3 Safari/534.3", "Mozilla/5.0 (X11; Ubuntu; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1864.6 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Chrome/36.0.1985.125 CrossBrowser/36.0.1985.138 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Avast/70.0.917.102", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1615.0 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.14 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.14", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/6.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3608.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.81 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3251.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/54.2.133 Chrome/48.2.2564.133 Safari/537.36", "24.0.1284.0.0 (Windows NT 5.1) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/24.0.1284.0.3.742.3 Safari/534.3", "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/54.2.133 Chrome/48.2.2564.133 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/54.2.133 Chrome/48.2.2564.133 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.18 Safari/535.1", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2427.7 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.61 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Chrome/36.0.1985.125 CrossBrowser/36.0.1985.138 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.45 Safari/537.36", "Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.104 Safari/537.36", "24.0.1284.0.0 (Windows NT 5.1) AppleWebKit/534.0 (KHTML, like Gecko) Chrome/24.0.1284.0.3.742.3 Safari/534.3", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko; Google Web Preview) Chrome/27.0.1453 Safari/537.36,gzip(gfe)", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.45 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.45", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.150 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.102 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2419.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Chrome/36.0.1985.125 CrossBrowser/36.0.1985.138 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1204.0 Safari/537.1", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2700.0 Safari/537.36#", "Mozilla/5.0 (Windows NT 10.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36", "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.16 (KHTML, like Gecko) Chrome/5.0.335.0 Safari/533.16", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.68 Safari/537.36", "Mozilla/5.0 (Windows; U; Windows 95) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.43 Safari/535.1", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2700.0 Safari/537.36#", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.114 Safari/537.36", "Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/530.6 (KHTML, like Gecko) Chrome/2.0.174.0 Safari/530.6", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/538 (KHTML, like Gecko) Chrome/36 Safari/538", "Mozilla/5.0 (Windows; U; Windows 95) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.43 Safari/535.1", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.18 Safari/535.1", "Mozilla/5.0 (X11; Linux x86_64; 6.1) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/17.0.1410.63 Safari/537.31", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2583.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2151.2 Safari/537.36", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.18 Safari/535.1", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/536.36 (KHTML, like Gecko) Chrome/67.2.3.4 Safari/536.36", "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/530.5 (KHTML, like Gecko) Chrome/2.0.172.0 Safari/530.5", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.69 Safari/537.36", "Mozilla/5.0 (Windows NT 10.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.81 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Safari/537.36 EdgA/41.0.0.1662", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.1"]
        userAgent = random.choice(userAgents)
        return userAgent

nsfwTypes = ["boobs", "ass", "hentai", "porngif", "pussy", "tits", "tittydrop", "tittypop", "titty", "femboy"]
def get_nsfw(type):
        types = nsfwTypes
        if type not in types:
            return "Invalid type."
        else:
            for type2 in types:
                if type == type2:
                    request = requests.get(f"https://www.reddit.com/r/{type2}/random.json", headers={'User-agent': get_random_user_agent()}).json()
                    url = request[0]["data"]["children"][0]["data"]["url"]
                    if "redgifs" in str(url):
                        url = request[0]["data"]["children"][0]["data"]["preview"]["reddit_video_preview"]["fallback_url"]
                    return url

def setup(bot, RPC, presence_loop):
    @bot.command(name="prefix")
    async def prefix(ctx, new_prefix: str):
        response = await ctx.send(f"Prefix updated to `{new_prefix}`")
        settings = load_settings()
        settings["settings"]["prefix"] = new_prefix
        save_settings(settings)
        await response.delete()
        python_executable = os.path.join(lunaris_folder, 'Lunaris', 'Scripts', 'python.exe')
        main_script = os.path.join(lunaris_folder, 'main.py')
        subprocess.run([python_executable, main_script], check=True)
    
    @bot.command(name="log_message")
    async def log_message(ctx, *, message: str):
        if hasattr(bot, 'log'):
            bot.log(message, style="cyan")
        else:
            print(message)
        await ctx.send(f"Logged message: {message}", delete_after = 5)

    @bot.command(name='help')
    async def help(ctx):
        settings = load_settings()["settings"]
        if settings["mode"] == "silent":
            bot.log("Help command is broken in silent mod due to the new UI", style="cyan")
            return
        help_text = f"""
            **Help - List of Commands**

                **General Commands**
                    `prefix <new_prefix>` - Change the bot's prefix.
                    `mode <normal/silent>` - Set the bot mode to normal or silent.
                    `ping` - Check the bot's latency.
                    `pingreplier <enable/disable>` - Enable or disable the ping replier.
                    `pingreply <message>` - Set the ping replier response message.
                    `rpc <enable/disable>` - Enable or disable Rich Presence.

                **Fun Commands**
                    `boobs` - Get a random boobs image.
                    `ass` - Get a random ass image.
                    `pussy` - Get a random pussy image.
                    `abc` - Display the alphabet.
                    `100` - Count to 100.
                    `first-message` - Get the first message in the current channel.
                    `gentoken` - Generate a random Discord token.
                    `nitro` - Generate a random Nitro code.
                    `911` - 9/11 joke command.
                    `cum` - Cum joke command.
                    `tweet <username> <message>` - Generate a fake tweet image.
                    `phcomment <user> <message>` - Generate a fake PornHub comment image.
                    `superghostping <message> <user>` - Super ghost ping a user with a message.
                    `hack <user>` - Fake hack a user.
                    `virus <name>` - Fake virus command.
                    `wizz` - Fake wizz command.
                    `dick <user>` - Measure a user's dick size.
                    `gay <user>` - Measure a user's gay percentage.
                    `massreact <emote>` - Mass react to the last 20 messages in the channel.
                    `messagecrypted <message>` - Encrypt the message you put
                    `messagedecrypt <message>` - Decrypt the crypted text  
                    `clear` - Clear the chat.

                **Utility Commands**
                    `eval ```py \n<python code>\n```` - Execute the python code on your pc and return the response.
                    `log_message <message>` - Log a message of your choice.
                    `shutdown` - Shut down the bot.
        """
        await ctx.send(help_text)



    @bot.command(name = "mode")
    async def mode(ctx, mode: str):
        if mode.lower() == "normal":
            response = await ctx.send("Mode set to normal.")
            settings = load_settings()
            settings["settings"]["mode"] = "normal"
            save_settings(settings)
            bot.log("Mode updated to: Normal", style="cyan")
        elif mode.lower() == "silent":
            response = await ctx.send("Mode set to silent.")
            settings = load_settings()
            settings["settings"]["mode"] = "silent"
            save_settings(settings)
            bot.log("Mode updated to: Silent", style="cyan")
        else:
            response = await ctx.send("Invalid mode. Please use `normal` or `silent`.")
        asyncio.create_task(delete_response_after_delay(response, 5))

    @bot.command(name = "risky")
    async def risky(ctx, status: str):
        settings = load_settings()
        if status.lower() == "enable":
            if settings["settings"]["mode"] == "silent":
                bot.log("Risky commands enabled.", style="cyan")
            elif settings["settings"]["mode"] == "normal":
                response = await ctx.send("Risky commands enabled.")
            settings["settings"]["risky"] = True
            save_settings(settings)
        elif status.lower() == "disable":
            if settings["settings"]["mode"] == "silent":
                bot.log("Risky commands disabled.", style="cyan")
            elif settings["settings"]["mode"] == "normal":
                response = await ctx.send("Risky commands disabled.")
            settings["settings"]["risky"] = False
            save_settings(settings)
        else:
            response = await ctx.send("Invalid status. Please use `enable` or `disable`.")
        asyncio.create_task(delete_response_after_delay(response, 5))

    @bot.command(name="ping")
    async def ping(ctx):
        response = await ctx.send(f"`{round(bot.latency * 1000)} ms`")
        asyncio.create_task(delete_response_after_delay(response, 5))

    @bot.command(name="pingreplier")
    async def pingreplier(ctx, status: str):
        if status.lower() == "enable":
            ping_replier["enabled"] = True
            response = await ctx.send("Ping replier enabled.")
        elif status.lower() == "disable":
            ping_replier["enabled"] = False
            response = await ctx.send("Ping replier disabled.")
        else:
            response = await ctx.send("Invalid status. Please use `enable` or `disable`.")
        asyncio.create_task(delete_response_after_delay(response, 5))
        settings = load_settings()
        settings["settings"]["ping_replier"] = ping_replier
        save_settings(settings)

    @bot.command(name="pingreply")
    async def pingreply(ctx, *, message: str):
        ping_replier["message"] = message
        response = await ctx.send("Ping replier response updated.")
        asyncio.create_task(delete_response_after_delay(response, 5))
        settings = load_settings()
        settings["settings"]["ping_replier"]["message"] = message
        save_settings(settings)

    @bot.command(name="rpc")
    async def rpc(ctx, status: str):
        if status.lower() == "enable":
            rpc_settings["enabled"] = True
            response = await ctx.send("Rich Presence enabled.")
            presence_loop.start()
        elif status.lower() == "disable":
            rpc_settings["enabled"] = False
            response = await ctx.send("Rich Presence disabled.")
            presence_loop.cancel()
            presence_loop.stop()
            await RPC.clear()
        else:
            response = await ctx.send("Invalid status. Please use `enable` or `disable`.")
        asyncio.create_task(delete_response_after_delay(response, 5))
        settings = load_settings()
        settings["settings"]["rpc"] = rpc_settings
        save_settings(settings)
        if status.lower() == "enable":
            python_executable = os.path.join(lunaris_folder, 'Lunaris', 'Scripts', 'python.exe')
            main_script = os.path.join(lunaris_folder, 'main.py')
            subprocess.run([python_executable, main_script], check=True)
            os.execv(sys.executable, ['python'] + main_script)

    @bot.command(name = "boobs")
    async def boobs(ctx):
        settings = load_settings()
        if settings["settings"]["risky"] == False:
            response = await ctx.send("Risky commands are disabled")
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        type = "boobs"
        image = get_nsfw(type)
        if image.endswith("png") or image.endswith("jpeg") or image.endswith("jpg") or image.endswith("gif"): 
            await ctx.send(image)
        else:
            await ctx.send(image)

    @bot.command(name = "ass")
    async def ass(ctx):
        settings = load_settings()
        if settings["settings"]["risky"] == False:
            response = await ctx.send("Risky commands are disabled")
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        type = "ass"
        image = get_nsfw(type)
        if image.endswith("png") or image.endswith("jpeg") or image.endswith("jpg") or image.endswith("gif"):
            await ctx.send(image)       
        else:  
            await ctx.send(image)

    @bot.command(name = "pussy")
    async def pussy(ctx):
        settings = load_settings()
        if settings["settings"]["risky"] == False:
            response = await ctx.send("Risky commands are disabled")
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        type = "pussy"
        image = get_nsfw(type)
        if image.endswith("png") or image.endswith("jpeg") or image.endswith("jpg") or image.endswith("gif"):
            await ctx.send(image)    
        else:  
            await ctx.send(image)    

    @bot.command(name = "abc")
    async def abc(ctx):
        ABC = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
        message = await ctx.send(ABC[0])
        await asyncio.sleep(2)
        for _next in ABC[1:]:
            await message.edit(content=_next)
            await asyncio.sleep(2)

    @bot.command(name = "100")
    async def _100(ctx):
        message = await ctx.send("Starting count to **100**")
        await asyncio.sleep(2)
        for i in range(100):
            await message.edit(content=i)
            await asyncio.sleep(2)

    @bot.command(name = "first-message")
    async def first_message(ctx):
        channel = ctx.channel
        try:
            first_message = (await channel.history(limit=1, oldest_first=True).flatten())[0]
            await ctx.send(f"First Message: {first_message.jump_url}")
        except Exception as e:
            await ctx.send(f"Error: {e}")

    @bot.command(name = "gentoken")
    async def gentoken(ctx, user: discord.Member=None):
        code = "ODA"+random.choice(string.ascii_letters)+''.join(random.choice(string.ascii_letters + string.digits) for _ in range(20))+"."+random.choice(string.ascii_letters).upper()+''.join(random.choice(string.ascii_letters + string.digits) for _ in range(5))+"."+''.join(random.choice(string.ascii_letters + string.digits) for _ in range(27))
        if user is None:
            await ctx.send(''.join(code))
            return
        await ctx.send(user.mention + " token is: " + "".join(code))

    @bot.command(name = "nitro")
    async def nitro(ctx):
        code = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
        await ctx.send(f'https://discord.gift/{code}')

    @bot.command(name = "911")
    async def _911(ctx):
        invis = ""
        message = await ctx.send(f'''
        {invis}:man_wearing_turban::airplane:    :office:           
        ''')
        await asyncio.sleep(0.5)
        await message.edit(content=f'''
        {invis} :man_wearing_turban::airplane:   :office:           
        ''')
        await asyncio.sleep(0.5)
        await message.edit(content=f'''
        {invis}  :man_wearing_turban::airplane:  :office:           
        ''')
        await asyncio.sleep(0.5)
        await message.edit(content=f'''
        {invis}   :man_wearing_turban::airplane: :office:           
        ''')
        await asyncio.sleep(0.5)
        await message.edit(content=f'''
        {invis}    :man_wearing_turban::airplane::office:           
        ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
        :boom::boom::boom:    
        ''')

    @bot.command(name = "cum")
    async def cum(ctx):
        settings = load_settings()
        if settings["settings"]["risky"] == False:
            response = await ctx.send("Risky commands are disabled")
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        message = await ctx.send('''
            :ok_hand:            :smile:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant:''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                      :ok_hand:            :smiley:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:  
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                      :ok_hand:            :grimacing:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant:  
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                      :ok_hand:            :persevere:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:   
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                      :ok_hand:            :confounded:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:=D 
             :trumpet:      :eggplant: 
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                       :ok_hand:            :tired_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D 
             :trumpet:      :eggplant:    
             ''')
        await asyncio.sleep(0.5)
        await message.edit(contnet='''
                       :ok_hand:            :weary:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8=:punch:= D:sweat_drops:
             :trumpet:      :eggplant:        
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                       :ok_hand:            :dizzy_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D :sweat_drops:
             :trumpet:      :eggplant:                 :sweat_drops:
     ''')
        await asyncio.sleep(0.5)
        await message.edit(content='''
                       :ok_hand:            :drooling_face:
   :eggplant: :zzz: :necktie: :eggplant: 
                   :oil:     :nose:
                 :zap: 8==:punch:D :sweat_drops:
             :trumpet:      :eggplant:                 :sweat_drops:
     ''')

    @bot.command(name = "tweet")
    async def tweet(ctx, username: str = None, *, message: str = None):
        if username is None or message is None:
            response = await ctx.send(f'[ERROR]: Invalid input! Command: {settings["prefix"]}tweet <username> <message>')
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        else:
            async with aiohttp.ClientSession() as cs:
                async with cs.get(f"https://nekobot.xyz/api/imagegen?type=tweet&username={username}&text={message}") as r:
                    res = await r.json()
                    try:
                        async with aiohttp.ClientSession() as session:
                            async with session.get(str(res['message'])) as resp:
                                image = await resp.read()
                        with io.BytesIO(image) as file:
                            await ctx.send(file=discord.File(file, f"lunaris_tweet.png"))
                    except:
                        await ctx.send(res['message'])

    @bot.command(name = "phcomment")
    async def phcomment(ctx, user: discord.Member = None, *, args=None):
        if user is None or args is None:
            await ctx.send(f'[ERROR]: Invalid input! Command: {settings["prefix"]}phcomment <message>')
            return
        endpoint = "https://nekobot.xyz/api/imagegen?type=phcomment&text=" + args + "&username=" + user.name + "&image=" + str(
            user.avatar_url_as(format="png"))
        r = requests.get(endpoint)
        res = r.json()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(res["message"]) as resp:
                    image = await resp.read()
            with io.BytesIO(image) as file:
                await ctx.send(file=discord.File(file, f"lunaris_pornhub_comment.png"))
        except:
            await ctx.send(res["message"])

    @bot.command(name = "superghostping")
    async def superghostping(ctx, user: discord.Member, *, message):
        if user is None:
            response = await ctx.send(f'[ERROR]: Invalid input! Command: {settings["prefix"]}superghostping <message> <user>')
            asyncio.create_task(delete_response_after_delay(response, 5))
            return
        await ctx.send(f"{message}||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||<@{user.id}>")

    @bot.command(name="hack")
    async def hack(ctx, user: discord.Member = None):
        gender = ["Male", "Female", "Trans", "Other", "Retard"]
        age = str(random.randrange(10, 25))
        height = ['4\'6\"', '4\'7\"', '4\'8\"', '4\'9\"', '4\'10\"', '4\'11\"', '5\'0\"', '5\'1\"', '5\'2\"', '5\'3\"',
                  '5\'4\"', '5\'5\"', '5\'6\"', '5\'7\"', '5\'8\"', '5\'9\"', '5\'10\"', '5\'11\"', '6\'0\"', '6\'1\"', '6\'2\"', '6\'3\"',
                  '6\'4\"', '6\'5\"', '6\'6\"', '6\'7\"', '6\'8\"', '6\'9\"', '6\'10\"', '6\'11\"']
        weight = str(random.randrange(60, 300))
        hair_color = ["Black", "Brown", "Blonde", "White", "Gray", "Red"]
        skin_color = ["White", "Pale", "Brown", "Black", "Light-Skin"]
        religion = ["Christian", "Muslim", "Atheist", "Hindu", "Buddhist", "Jewish"]
        sexuality = ["Straight", "Gay", "Homo", "Bi", "Bi-Sexual", "Lesbian", "Pansexual"]
        education = ["High School", "College", "Middle School", "Elementary School", "Pre School",
                     "Retard never went to school LOL"]
        ethnicity = ["White", "African American", "Asian", "Latino", "Latina", "American", "Mexican", "Korean", "Chinese",
                     "Arab", "Italian", "Puerto Rican", "Non-Hispanic", "Russian", "Canadian", "European", "Indian"]
        occupation = ["Retard has no job LOL", "Certified discord retard", "Janitor", "Police Officer", "Teacher",
                      "Cashier", "Clerk", "Waiter", "Waitress", "Grocery Bagger", "Retailer", "Sales-Person", "Artist",
                      "Singer", "Rapper", "Trapper", "Discord Thug", "Gangster", "Discord Packer", "Mechanic", "Carpenter",
                      "Electrician", "Lawyer", "Doctor", "Programmer", "Software Engineer", "Scientist"]
        salary = ["Retard makes no money LOL", "$" + str(random.randrange(0, 1000)), '<$50,000', '<$75,000', "$100,000",
                  "$125,000", "$150,000", "$175,000", "$200,000+"]
        location = ["Retard lives in his mom's basement LOL", "America", "United States", "Europe", "Poland", "Mexico",
                    "Russia", "Pakistan", "India", "Some random third world country", "Canada", "Alabama", "Alaska", "Arizona",
                    "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho",
                    "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts",
                    "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire",
                    "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
                    "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
                    "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]
        email = ["@gmail.com", "@yahoo.com", "@hotmail.com", "@outlook.com", "@protonmail.com", "@disposablemail.com",
                 "@aol.com", "@edu.com", "@icloud.com", "@gmx.net", "@yandex.com"]
        dob = f'{random.randrange(1, 13)}/{random.randrange(1, 32)}/{random.randrange(1950, 2021)}'
        name = ['James Smith', "Michael Smith", "Robert Smith", "Maria Garcia", "David Smith", "Maria Rodriguez",
                "Mary Smith", "Maria Hernandez", "Maria Martinez", "James Johnson", "Catherine Smoaks", "Cindi Emerick",
                "Trudie Peasley", "Josie Dowler", "Jefferey Amon", "Kyung Kernan", "Lola Barreiro",
                "Barabara Nuss", "Lien Barmore", "Donnell Kuhlmann", "Geoffrey Torre", "Allan Craft",
                "Elvira Lucien", "Jeanelle Orem", "Shantelle Lige", "Chassidy Reinhardt", "Adam Delange",
                "Anabel Rini", "Delbert Kruse", "Celeste Baumeister", "Jon Flanary", "Danette Uhler", "Xochitl Parton",
                "Derek Hetrick", "Chasity Hedge", "Antonia Gonsoulin", "Tod Kinkead", "Chastity Lazar", "Jazmin Aumick",
                "Janet Slusser", "Junita Cagle", "Stepanie Blandford", "Lang Schaff", "Kaila Bier", "Ezra Battey",
                "Bart Maddux", "Shiloh Raulston", "Carrie Kimber", "Zack Polite", "Marni Larson", "Justa Spear"]
        phone = f'({random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)})-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}-{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}{random.randrange(0, 10)}'

        password = ['password', '123', 'mypasswordispassword', "iscool123", "isdaddy",
                    "daddy", "ilovediscord", "i<3discord", "furryporn456", "secret", "123456789", "apple49",
                    "redskins32", "princess", "dragon", "password1", "1q2w3e4r", "ilovefurries",
                    "letmein", "opensesame", "guessme", "notapassword", "nottelling", "whatsmypassword",
                    "rocks", "super", "forpresident", "bestpasswordever", 
                    "cantremember", "nananana", "iamgroot", "itsasecret", "swordfish", 
                    "thisisfine", "youshallnotpass", "spiderman", "batman", "iambatman", 
                    "whydoihavetodothis", "qwertyuiop", "asdfghjkl", "zxcvbnm", "password1234", 
                    "whatsmypasswordagain", "iamthebest", "godzilla123", "dinosaursrock", "unicornsrock", 
                    "mycatsname", "iamawesome", "n0tAp4ssw0rd", "trustno1", "monkey123", "letmeinpls", 
                    "openthedoor", "hackme", "tryandguess", "canttouchthis", "supersecret", "youllneverguess", 
                    "openpls", "justtesting", "thisone", "thatisnotpossible", "whatever123", "anything123", 
                    "mybirthday", "whodis", "newphonewhodis", "donotenter", "knockknock", "knockknock123", 
                    "whosthere", "noneofyourbiz", "comefindme", "iaminvisible", "goodluck123", "impossible2guess", "slaveofyutsana"]

        if user is None:
            user = ctx.author

        message = await ctx.send(f"`Hacking {user.name}...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user.name}...\nHacking into the mainframe...\n`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Hacking {user.name}...\nHacking into the mainframe...\nCaching data...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user.name}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\n`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user.name}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"`Hacking {user.name}...\nHacking into the mainframe...\nCaching data...\nCracking SSN information...\nBruteforcing love life details...\nFinalizing life-span dox details\n`")
        await asyncio.sleep(1)
        await message.edit(
            content=f"```Successfully hacked {user.name}\nName: {random.choice(name)}\nGender: {random.choice(gender)}\nAge: {age}\nHeight: {random.choice(height)}\nWeight: {weight}\nHair Color: {random.choice(hair_color)}\nSkin Color: {random.choice(skin_color)}\nDOB: {dob}\nLocation: {random.choice(location)}\nPhone: {phone}\nE-Mail: {user.name + random.choice(email)}\nPasswords: {random.choices(password, k=3)}\nOccupation: {random.choice(occupation)}\nAnnual Salary: {random.choice(salary)}\nEthnicity: {random.choice(ethnicity)}\nReligion: {random.choice(religion)}\nSexuality: {random.choice(sexuality)}\nEducation: {random.choice(education)}```")

    @bot.command(name = "virus")
    async def virus(ctx, name):
        message = await ctx.send(f"`[                       ] / {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓                    ] / {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓                ] - {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓▓▓▓▓▓           ] \ {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓▓▓▓▓▓▓▓         ] | {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ] / {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   ] - {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`[▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] \ {name}.exe Packing files...`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Successfully downloaded {name}.exe`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Injecting {name}.exe.   |`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Injecting {name}.exe..  /`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Injecting {name}.exe... -`")
        await asyncio.sleep(1)
        await message.edit(content=f"`Successfully Injected {name}.exe`")

    @bot.command(name = "wizz")
    async def wizz(ctx):
        if isinstance(ctx.message.channel, discord.TextChannel):
            initial = random.randrange(0, 60)
            message = await ctx.send(f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\n`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...\nDeleting {len(ctx.guild.categories)} Categories...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...\nDeleting {len(ctx.guild.categories)} Categories...\nDeleting Webhooks...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...\nDeleting {len(ctx.guild.categories)} Categories...\nDeleting Webhooks...\nDeleting Emojis`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...\nDeleting {len(ctx.guild.categories)} Categories...\nDeleting Webhooks...\nDeleting Emojis\nInitiating Ban Wave...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.guild.name}, will take {initial} seconds to complete`\n`Deleting {len(ctx.guild.roles)} Roles...\nDeleting {len(ctx.guild.text_channels)} Text Channels...\nDeleting {len(ctx.guild.voice_channels)} Voice Channels...\nDeleting {len(ctx.guild.categories)} Categories...\nDeleting Webhooks...\nDeleting Emojis\nInitiating Ban Wave...\nInitiating Mass-DM`")
        elif isinstance(ctx.message.channel, discord.DMChannel):
            initial = random.randrange(1, 60)
            message = await ctx.send(
                f"`Wizzing {ctx.message.channel.recipient.name}, will take {initial} seconds to complete`\n")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.recipient.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\n`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.recipient.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.recipient.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...\nDeleting {random.randrange(0, 1000)} Pinned Messages...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.recipient.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...\nDeleting {random.randrange(0, 1000)} Pinned Messages...\n`")
        elif isinstance(ctx.message.channel, discord.GroupChannel):
            initial = random.randrange(1, 60)
            message = await ctx.send(f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\n`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...\nDeleting {random.randrange(0, 1000)} Pinned Messages...`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...\nDeleting {random.randrange(0, 1000)} Pinned Messages...\n`")
            await asyncio.sleep(1)
            await message.edit(
                content=f"`Wizzing {ctx.message.channel.name}, will take {initial} seconds to complete`\n`Saving {random.randrange(0, 1000)} Messages...\nCaching {random.randrange(0, 1000)} Messages...\nDeleting {random.randrange(0, 1000)} Pinned Messages...\nKicking {len(ctx.message.channel.recipients)} Users...`")

    @bot.command(name = "dick")
    async def dick(ctx, *, user: discord.Member=None):
        if user is None:
            user = ctx.author
        size = random.randint(1, 15)
        dong = ""
        for _i in range(0, size):
            dong += "="
        await ctx.send(f"**{user.name}** Dick size\n8{dong}D")

    @bot.command(name = "gay")
    async def gay(ctx, *, user: discord.Member = None):
        if user is None:
            user = ctx.author
        pourcent = random.randint(0, 100)
        await ctx.send(f"**{user.name}** is gay at {pourcent}%")

    @bot.command(name = "massreact")
    async def massreact(ctx, emote=None):
        if emote is None:
            await ctx.send(f'[ERROR]: Invalid input! Command: {settings["prefix"]}massreact <emote>')
            return
        messages = await ctx.message.channel.history(limit=20).flatten()
        for message in messages:
            await message.add_reaction(emote)

    @bot.command(name = "messagecrypted")
    async def messagecrypted(ctx, *, message):
        message_byte = message.encode('ascii')
        base64_bytes = base64.b64encode(message_byte)
        base64_message = base64_bytes.decode('ascii')
        await ctx.send(base64_message)

    @bot.command(name = "messagedecrypt")
    async def messagedecrypt(ctx, *, message):
        base64_message = message
        base64_bytes = base64_message.encode('ascii')
        message_bytes = base64.b64decode(base64_bytes)
        message = message_bytes.decode('ascii')
        await ctx.send(message)

    @bot.command(name="eval")
    async def eval(ctx, *, code):
        if code.startswith("```") and code.endswith("```"):
            code = code[3:-3].strip()
            first_line = code.split("\n")[0]
            if first_line in ["py", "python"]:
                code = "\n".join(code.split("\n")[1:]).strip()

        buffer = io.StringIO()

        env = {
            'bot': bot,
            'ctx': ctx,
            'discord': discord,
            'commands': commands,
            'asyncio': asyncio,
            'aiohttp': aiohttp,
            're': re,
            'requests': requests,
            'time': time,
            'json': json,
            'os': os,
            'sys': sys,
        }

        env.update(globals())

        with contextlib.redirect_stdout(buffer):
            try:
                exec(code, env)
            except Exception as e:
                buffer.write(str(e))

        output = buffer.getvalue()

        if not output:
            output = "No output"

        response = await ctx.send(f"```{output}```")
        asyncio.create_task(delete_response_after_delay(response, 5))

    @bot.command(name = "clear")
    async def clear(ctx):
        await ctx.send('ﾠﾠ' + '\n' * 400 + 'ﾠﾠ')

    @bot.command(name="shutdown")
    async def shutdown(ctx):
        await asyncio.sleep(1)
        settings = load_settings()
        if settings["settings"]["rpc"]["enabled"]:
            await RPC.close()
        await bot.close()

