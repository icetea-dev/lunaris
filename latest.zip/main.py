import discord
import asyncio
import time
import json
import os
import sys
from discord.ext import commands, tasks
from pypresence import AioPresence
import helper.console as Console
from helper.commands import setup, load_settings

appdata_path = os.getenv('APPDATA')
lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
settings_file = os.path.join(lunaris_folder, 'settings', 'settings.json')

settings = load_settings()["settings"]

class Lunaris(commands.Bot):
    def __init__(self):
        intents = discord.Intents.all()
        super().__init__(command_prefix=settings["prefix"], self_bot=True, case_insensitive=True, intents=intents)
        self.csl = Console.Console()
        self.csl.clear()
        self.csl.title("Lunaris - Discord Selfbot")
        self.csl.info("Checking for updates...")
        self.csl.info("Starting Lunaris...")
        self.last_ping_times = {}

    async def check_for_updates(self):
        try:
            await self.updater.check_for_update()
        except Exception as e:
            self.csl.error(f"Error checking for updates: {e}")

if __name__ == "__main__":
    bot = Lunaris()
    RPC = AioPresence(settings["rpc"]["client_id"])

    @tasks.loop(seconds=60)
    async def presence_loop():
        if settings["rpc"]["enabled"]:
            buttons = []
            if settings["rpc"]["button1"]["enabled"]:
                buttons.append({
                    "label": settings["rpc"]["button1"]["label"],
                    "url": settings["rpc"]["button1"]["url"]
                })
            if settings["rpc"]["button2"]["enabled"]:
                buttons.append({
                    "label": settings["rpc"]["button2"]["label"],
                    "url": settings["rpc"]["button2"]["url"]
                })
            await RPC.update(
                state=settings["rpc"]["state"],
                details=settings["rpc"]["details"],
                large_image=settings["rpc"]["large_image"],
                buttons=buttons
            )

    setup(bot, RPC, presence_loop)
    
    @bot.listen("on_ready")
    async def on_ready():
        bot.csl.clear()
        print('''
 __                                                __           
/  |                                              /  |          
$$ |       __    __  _______    ______    ______  $$/   _______ 
$$ |      /  |  /  |/       \  /      \  /      \ /  | /       |
$$ |      $$ |  $$ |$$$$$$$  | $$$$$$  |/$$$$$$  |$$ |/$$$$$$$/ 
$$ |      $$ |  $$ |$$ |  $$ | /    $$ |$$ |  $$/ $$ |$$      \ 
$$ |_____ $$ \__$$ |$$ |  $$ |/$$$$$$$ |$$ |      $$ | $$$$$$  |
$$       |$$    $$/ $$ |  $$ |$$    $$ |$$ |      $$ |/     $$/ 
$$$$$$$$/  $$$$$$/  $$/   $$/  $$$$$$$/ $$/       $$/ $$$$$$$/  
                                                                
                                                                
                                                                             ''')
        bot.csl.success(f"Logged in as {bot.user.name}")
        bot.csl.info(f"Prefix: {settings['prefix']}")
        bot.csl.info(f"Commands loaded: {len(bot.commands)}")
        if settings["rpc"]["enabled"]:
            await RPC.connect()
            bot.csl.info("Rich Presence enabled")
            presence_loop.start()
        bot.csl.info(f"Ping replier: {settings['ping_replier']['enabled']}")
        bot.csl.info(f"Number of Guild Synced: {len(bot.guilds)}")
        bot.csl.info(f"Number of Friend: {len(bot.user.friends)}")

    @bot.listen("on_message")
    async def on_message(message):
        if message.author == bot.user:
            if message.content.startswith(settings["prefix"]):
                await message.delete()
            return
        if f"<@{bot.user.id}>" in message.content:
            if settings["log"]["log_ping_webhook"] != "":
                webhook = discord.Webhook.from_url(settings["log"]["log_ping_webhook"], adapter=discord.RequestsWebhookAdapter())
                if message.guild is None:
                    webhook.send(f"**{message.author.name}** mentioned you in a DM\n[Jump to message](https://discord.com/channels/@me/{message.channel.id}/{message.id})")
                else:
                    webhook.send(f"**{message.author.name}** mentioned you\n[Jump to message](https://discord.com/channels/{message.guild.id}/{message.channel.id}/{message.id})")
            if settings["ping_replier"]["enabled"] != False:
                current_time = time.time()
                last_ping_time = bot.last_ping_times.get(message.channel.id, 0)
                if current_time - last_ping_time > 5:
                    bot.last_ping_times[message.channel.id] = current_time
                    async with message.channel.typing():
                        await asyncio.sleep(2)
                    await message.channel.send(settings["ping_replier"]["message"])

    @bot.listen("on_command_error")
    async def on_command_error(ctx, error):
        error_str = str(error)
        error = getattr(error, "original", error)
        if isinstance(error, commands.CommandNotFound):
            if settings["mode"] == "normal":
                await ctx.send(f"Command not found: `{error}`", delete_after=3)
            elif settings["mode"] == "silent":
                bot.csl.error(f"Command not found: {error}")
        elif isinstance(error, commands.MissingRequiredArgument):
            if settings["mode"] == "normal":
                await ctx.send(f"Missing required argument: `{error}`", delete_after=3)
            elif settings["mode"] == "silent":
                bot.csl.error(f"Missing required argument: {error}")
        elif isinstance(error, discord.errors.Forbidden):
            if settings["mode"] == "normal":
                await ctx.send(f"404 Forbidden Access: {error}", delete_after=3)
            elif settings["mode"] == "silent":
                bot.csl.error(f"404 Forbidden Access: {error}")
        elif "Cannot send an empty message" in error_str:
            if settings["mode"] == "normal":
                await ctx.send("Cannot send an empty message", delete_after=3)
            elif settings["mode"] == "silent":
                bot.csl.error("Cannot send an empty message")
        else:
            if settings["mode"] == "normal":
                await ctx.send(f"An error occurred: {error}", delete_after=3)
            elif settings["mode"] == "silent":
                bot.csl.error(f"An error occurred: {error}")

    try:
        bot.run(settings["token"], bot=False, reconnect=True)
    except discord.errors.LoginFailure:
        bot.csl.error("Failed to login: Invalid token")
    except Exception as e:
        bot.csl.error(f"An error occurred: {e}")
