import discord, re, requests, asyncio, time, os, subprocess
from discord.ext import commands, tasks
from pypresence import AioPresence
from rich.console import Console as RichConsole
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.layout import Layout

from helper.commands import setup, load_settings

appdata_path = os.getenv('APPDATA')
lunaris_folder = os.path.join(appdata_path, 'Lunaris Selfbot')
settings_file = os.path.join(lunaris_folder, 'settings', 'settings.json')

settings = load_settings()["settings"]

intents = discord.Intents.all()

os.system('title Lunaris Selfbot')
subprocess.run('cls', shell=True)

class Lunaris(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=settings["prefix"], self_bot=True, intents=intents)
        self.console = RichConsole()
        self.start_time = time.time()
        self.last_ping_times = {}
        self.logs = []
        self.welcome_text = Text('''
 __                                                __           
/  |                                              /  |          
$$ |       __    __  _______    ______    ______  $$/   _______ 
$$ |      /  |  /  |/       \  /      \  /      \ /  | /       |
$$ |      $$ |  $$ |$$$$$$$  | $$$$$$  |/$$$$$$  |$$ |/$$$$$$$/ 
$$ |      $$ |  $$ |$$ |  $$ | /    $$ |$$ |  $$/ $$ |$$      \ 
$$ |_____ $$ \__$$ |$$ |  $$ |/$$$$$$$ |$$ |      $$ | $$$$$$  |
$$       |$$    $$/ $$ |  $$ |$$    $$ |$$ |      $$ |/     $$/ 
$$$$$$$$/  $$$$$$/  $$/   $$/  $$$$$$$/ $$/       $$/ $$$$$$$/  
                                                                
                                                                
                                                                             ''', style="bold green")
        self.layout = self.create_layout()

        self.previous_states = {
            "ping_replier": settings["ping_replier"]["enabled"],
            "mode": settings["mode"],
            "nitro_sniper": settings["nitro-sniper"],
            "rpc": settings["rpc"]["enabled"]
        }

    async def check_for_updates(self):
        try:
            await self.updater.check_for_update()
        except Exception as e:
            self.log(f"Error checking for updates: {e}", style="red")

    def create_layout(self):
        layout = Layout()
        header_size = len(self.welcome_text.plain.split("\n")) + 2
        layout.split(
            Layout(name="header", size=header_size),
            Layout(name="main", ratio=1)
        )
        layout["main"].split_row(
            Layout(name="stats", ratio=1),
            Layout(name="log", ratio=2)
        )
        return layout

    def log(self, message, style="white"):
        self.logs.append((message, style))
        if len(self.logs) > 10:
            self.logs.pop(0)

    async def update_status(self):
        with Live(self.layout, refresh_per_second=1, console=self.console, auto_refresh=True):
            while True:
                uptime_seconds = int(time.time() - self.start_time)
                uptime_str = time.strftime('%H:%M:%S', time.gmtime(uptime_seconds))

                if settings["ping_replier"]["enabled"] != self.previous_states["ping_replier"] or \
                   settings["mode"] != self.previous_states["mode"] or \
                   settings["nitro-sniper"] != self.previous_states["nitro_sniper"] or \
                   settings["rpc"]["enabled"] != self.previous_states["rpc"]:
                    self.previous_states["ping_replier"] = settings["ping_replier"]["enabled"]
                    self.previous_states["mode"] = settings["mode"]
                    self.previous_states["nitro_sniper"] = settings["nitro-sniper"]
                    self.previous_states["rpc"] = settings["rpc"]["enabled"]

                self.layout["stats"].update(Panel(self.generate_stats_table(uptime_str), title="Stats\n", border_style="bold green"))
                self.layout["log"].update(self.generate_logs_panel())
                await asyncio.sleep(1)

    def generate_stats_table(self, uptime_str):
        settings = load_settings()["settings"]
        table = Table(show_header=False, box=None)
        table.add_column("Metric", style="bold")
        table.add_column("Value", style="magenta")

        table.add_row("")
        table.add_row("Account", str(self.user.name))
        table.add_row("Uptime", uptime_str)
        table.add_row("Guilds", str(len(self.guilds)))
        table.add_row("Friends", str(len(self.user.friends)))
        table.add_row("Prefix", settings['prefix'])
        table.add_row("Commands", str(len(self.commands)))
        table.add_row("Ping Replier", str(settings['ping_replier']['enabled']))
        table.add_row("Mode", settings['mode'])
        table.add_row("Nitro Sniper", str(settings['nitro-sniper']))
        table.add_row("RPC", str(settings['rpc']['enabled']))

        return table

    def generate_logs_panel(self):
        log_table = Table(show_header=False, box=None)
        log_table.add_column("Log")

        for message, style in self.logs:
            log_table.add_row(Text(message, style=style))

        return Panel(log_table, title="Log", border_style="bold blue")


if __name__ == "__main__":
    bot = Lunaris()
    RPC = AioPresence(settings["rpc"]["client_id"])

    bot.remove_command('help')

    @tasks.loop(seconds=60)
    async def presence_loop():
        if settings["rpc"]["enabled"]:
            buttons = []
            if settings["rpc"]["button1"]["enabled"]:
                buttons.append({
                    "label": settings["rpc"]["button1"]["label"],
                    "url": settings["rpc"]["button1"]["url"]
                })
            if settings["rpc"]["button2"]["enabled"]:
                buttons.append({
                    "label": settings["rpc"]["button2"]["label"],
                    "url": settings["rpc"]["button2"]["url"]
                })
            await RPC.update(
                state=settings["rpc"]["state"],
                details=settings["rpc"]["details"],
                large_image=settings["rpc"]["large_image"],
                buttons=buttons
            )

    setup(bot, RPC, presence_loop)
    
    @bot.listen("on_ready")
    async def on_ready():
        bot.console.clear()
        centered_text = Align.center(bot.welcome_text)
        bot.layout["header"].update(Panel(centered_text, title="Lunaris Selfbot", title_align="center", border_style="bold green"))
        bot.loop.create_task(bot.update_status())

    @bot.listen("on_message")
    async def on_message(message):
        if message.author == bot.user:
            if message.content.startswith(settings["prefix"]):
                await message.delete()
            return
        settings = load_settings()["settings"]
        if isinstance(message.channel, discord.TextChannel) and settings["nitro-sniper"]:
            async for msg in message.channel.history(limit=1):
                gift_code = None

                if 'discord.gift/' in msg.content:
                    gift_code = re.search(r'discord\.gift/(\w+)', msg.content)
                elif 'discord.com/gifts/' in msg.content:
                    gift_code = re.search(r'discord\.com/gifts/(\w+)', msg.content)
                elif 'discordapp.com/gifts/' in msg.content:
                    gift_code = re.search(r'discordapp\.com/gifts/(\w+)', msg.content)

                if gift_code:
                    gift_code = gift_code.group(1)

                    if gift_code in ["Udzwm3hrQECQBnEEFFCEwdSq", "vhnuzE2YkNCZ7sfYHHKebKXB", "BMHmv4FWEM5WVGnHUHCYFKMx"]:
                        return

                    gift = requests.post(f"https://discord.com/api/v9/entitlements/gift-codes/{gift_code}/redeem", headers={'Authorization': settings["token"]}).text
                    if 'This gift has been redeemed already.' in gift:
                        bot.log(f"Invalid gift: discord.gift/{gift_code} | {msg.channel.name} in {msg.guild.name}", style="red")
                    elif 'subscription_plan' in gift:
                        bot.log(f"Valid gift: discord.gift/{gift_code} | {msg.channel.name} in {msg.guild.name}", style="green")
                    elif 'Unknown Gift Code' in gift:
                        bot.log(f"Unknown gift: discord.gift/{gift_code} | {msg.channel.name} in {msg.guild.name}", style="yellow")

        if f"<@{bot.user.id}>" in message.content:
            async for msg in message.channel.history(limit=1):
                settings = load_settings()["settings"]
                if settings["log"]["log_ping_webhook"] != "":
                    webhook = discord.Webhook.from_url(settings["log"]["log_ping_webhook"], adapter=discord.RequestsWebhookAdapter())
                    if message.guild is None:
                        webhook.send(f"**{message.author.name}** mentioned you in a DM\nMessage Content: `{message.content}`\n[Jump to message](https://discord.com/channels/@me/{message.channel.id}/{message.id})")
                    else:
                        webhook.send(f"**{message.author.name}** mentioned you\nMessage Content: `{message.content}`\nIn: {message.guild.name}\n[Jump to message](https://discord.com/channels/{message.guild.id}/{message.channel.id}/{message.id})")
                if settings["ping_replier"]["enabled"]:
                    current_time = time.time()
                    last_ping_time = bot.last_ping_times.get(message.channel.id, 0)
                    if current_time - last_ping_time > 5:
                        bot.last_ping_times[message.channel.id] = current_time
                        async with message.channel.typing():
                            await asyncio.sleep(2)
                        await message.channel.send(settings["ping_replier"]["message"])

    @bot.listen("on_command_error")
    async def on_command_error(ctx, error):
        settings = load_settings()["settings"]
        error_str = str(error)
        error = getattr(error, "original", error)

        if isinstance(error, commands.CommandNotFound):
            if settings["mode"] == "normal":
                await ctx.send(f"Command not found: `{error}`", delete_after=3)
            elif settings["mode"] == "silent":
                bot.log(f"Command not found: {error}", style="red")

        elif isinstance(error, commands.MissingRequiredArgument):
            if settings["mode"] == "normal":
                await ctx.send(f"Missing required argument: `{error}`", delete_after=3)
            elif settings["mode"] == "silent":
                bot.log(f"Missing required argument: {error}", style="red")

        elif isinstance(error, discord.errors.Forbidden):
            if settings["mode"] == "normal":
                await ctx.send(f"404 Forbidden Access: {error}", delete_after=3)
            elif settings["mode"] == "silent":
                bot.log(f"404 Forbidden Access: {error}", style="red")

        elif "Cannot send an empty message" in error_str:
            if settings["mode"] == "normal":
                await ctx.send("Cannot send an empty message", delete_after=3)
            elif settings["mode"] == "silent":
                bot.log(f"Cannot send an empty message", style="red")

        else:
            if settings["mode"] == "normal":
                await ctx.send(f"An error occurred: {error}", delete_after=3)
            elif settings["mode"] == "silent":
                bot.log(f"An error occurred: {error}", style="red")

    try:
        bot.run(settings["token"], bot=False, reconnect=True)
    except discord.errors.LoginFailure:
        bot.log("Failed to login: Invalid token", style="red")
    except Exception as e:
        bot.log(f"An error occurred: {e}", style="red")
